<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         'i0F0!(QE[^ Qt7UGsA|X7a7zGo<7Y$Rn4||R0ch<9O$2![b2_E(xV6]-6y.5aS(n' );

define( 'SECURE_AUTH_KEY',  'W)+&[-Yh<OO8/MZ)[[pT+rRO~eU/cbB{6C6Phe(t>X^59k <bYa|:D$BjJjT;S_`' );

define( 'LOGGED_IN_KEY',    '(qn8fKhKOQ$QMDNU:!n(xF#uv*^rHZ^eR[Vo_`1SA9%IweTHOEVW:}8,t@b2;v2C' );

define( 'NONCE_KEY',        'b5dY8d*aFyjB.s9E_0Ug:4%urRzEQ7hb[ @:C5ISa|M?`HR0PJMCa.05nl~]=Gaw' );

define( 'AUTH_SALT',        'GRL8Jn~0Go1R]f@w#dH|:i0N&*e8Iwn`$yHK&-5*|+RqHSZq]o,f3KR6< uE/ha[' );

define( 'SECURE_AUTH_SALT', 'W+{k=/>]@hK%UQuYH0xA4iegFj?bs#z~wjI*[l<;ZN6*iDBCyc/B|2pqS?*ok(|>' );

define( 'LOGGED_IN_SALT',   'sYRpm4&;W ^P-kM BA`8K>mN8B^3S%Aa+]3qH.[:!1E%ZtZ}#HoRM3-]~.:DV4It' );

define( 'NONCE_SALT',       '2N^^TL9v3&dce2/Y9ntQx wLv8eh8OZ:a=9K8NV3F6:t~OwjLbZs`H p<.zq%g)&' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'default_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

